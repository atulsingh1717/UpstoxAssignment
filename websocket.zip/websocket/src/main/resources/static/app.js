var stompClient = null;

function setConnected(connected) {
    $("#connect").prop("disabled", connected);
    $("#disconnect").prop("disabled", !connected);
    if (connected) {
        $("#conversation").show();
    }
    else {
        $("#conversation").hide();
    }
    $("#greetings").html("");
}

function connect() {
    var socket = new SockJS('/gs-guide-websocket');
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function (frame) {
        setConnected(true);
        console.log('Connected: ' + frame);
        stompClient.subscribe('/topic/greetings', function (greeting) {
            showGreeting(JSON.parse(greeting.body));
        });
    });
}

function disconnect() {
    if (stompClient !== null) {
        stompClient.disconnect();
    }
    setConnected(false);
    console.log("Disconnected");
}

function sendForAll() {
	$.post("/manually/trigger",function(data){
		console.log(data);
	});
}

function sendForSample() {
    stompClient.send("/app/greetings", {}, JSON.stringify({
		"sym":"XXBTZUSD", "T":"Trade",  "P":6538.8, "Q":1, "TS":1538409739.0962, "side": "s", 
		"TS2":1538409748332169137}));
}

function showGreeting(object) {	
	
	if($("#marketHeader").length===0)
	{
		$("#greetingsHeader").append(
			"<tr id='marketHeader'>"
			  +"<th>Symbol</th>"
			  +"<th>Open</th>"
			  +"<th>High</th>"
			  +"<th>Low</th>"
			  +"<th>Close</th>"
			  +"<th>Quantity</th>"
			  +"<th>Graph Segment</th>"
		  +"<tr>");
	}
	if($("#"+object.symbol).length===0)
	{
		$("#greetings").append(
			"<tr id='"+object.symbol+"'>"
			  +"<td>"+object.symbol+"</td>"
			  +"<td>"+formatNumber(object.o)+"</td>"
			  +"<td>"+formatNumber(object.h)+"</td>"
			  +"<td>"+formatNumber(object.l)+"</td>"
			  +"<td>"+formatNumber(object.c)+"</td>"
			  +"<td>"+formatNumber(object.volume)+"</td>"
			  +"<td>"+object.bar_num+"</td>"
		  +"<tr>");
	}else
	{
		$("#"+object.symbol).html(
			  "<td>"+object.symbol+"</td>"
			  +"<td>"+formatNumber(object.o)+"</td>"
			  +"<td>"+formatNumber(object.h)+"</td>"
			  +"<td>"+formatNumber(object.l)+"</td>"
			  +"<td>"+formatNumber(object.c)+"</td>"
			  +"<td>"+formatNumber(object.volume)+"</td>"
			  +"<td>"+object.bar_num+"</td>");
	}
}

$(function () {
    $("form").on('submit', function (e) {
        e.preventDefault();
    });
    $( "#connect" ).click(function() { connect(); });
    $( "#disconnect" ).click(function() { disconnect(); });
    $( "#send1" ).click(function() { sendForAll(); });
	$( "#send2" ).click(function() { sendForSample(); });
});

function formatNumber(number) {
	return number.toLocaleString(undefined, { maximumFractionDigits: 10, minimumFractionDigits: 2 })
}