package com.websocket.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MarketDataModel implements Serializable
{
	/** To Avoid UnmarshalException */
	private static final long serialVersionUID = -4004477349348599148L;

	@JsonProperty(value = "sym")
	private String sym;

	@JsonProperty(value = "T")
	private String t;

	@JsonProperty(value = "P")
	private double p;

	@JsonProperty(value = "Q")
	private double q;

	@JsonProperty(value = "TS")
	private double ts;

	@JsonProperty(value = "side")
	private String side;

	@JsonProperty(value = "TS2")
	private long ts2;
}
