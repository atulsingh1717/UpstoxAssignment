package com.websocket.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
public class OpenHiLowCloseDataModel
{
	@JsonProperty(value = "o")
	private double o;

	@JsonProperty(value = "h")
	private double h;

	@JsonProperty(value = "l")
	private double l;

	@JsonProperty(value = "c")
	private double c;

	@JsonProperty(value = "volume")
	private double volume;

	@JsonProperty(value = "event")
	private String event;

	@JsonProperty(value = "symbol")
	private String symbol;

	@JsonProperty(value = "bar_num")
	private long bar_num;

	@JsonIgnore
	private boolean timeSlotChange;

}
