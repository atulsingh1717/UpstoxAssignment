package com.websocket.config;

import java.util.concurrent.Executor;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import net.sf.ehcache.config.CacheConfiguration;

@Configuration
@EnableCaching
public class GeneralConfiguration
{

	@Value("${thread.core.pool.size: 1}")
	private int corePoolSize;

	@Value("${thread.max.pool.size: 4}")
	private int maxPoolSize;
	
	@Value("${markectdata.cacheName: openHighLowCloseDataCache}")
	private String cacheName;
	

	@Bean(name="taskExecutor")
	public Executor taskExecutor()
	{
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(corePoolSize);
		executor.setMaxPoolSize(maxPoolSize);
		executor.setThreadNamePrefix("Executor-");
		executor.initialize();
		return executor;
	}
	
	@Bean
	public Cache cache(CacheManager cacheManager) 
	{
		return cacheManager.getCache(cacheName);
	}
	
	@Bean 
	public CacheManager cacheManager(EhCacheManagerFactoryBean ehCacheCacheManageFactory) 
	{
	    // testEhCache Configuration - create configuration of cache that previous required XML
         CacheConfiguration ehCacheConfig = new CacheConfiguration()
            .eternal(false)                     // if true, timeouts are ignored
            .timeToIdleSeconds(50000)           // time since last accessed before item is marked for removal
            .timeToLiveSeconds(50000)           // time since inserted before item is marked for removal
            .maxEntriesLocalHeap(100000)        // total items that can be stored in cache
            .memoryStoreEvictionPolicy("LRU")   // eviction policy for when items exceed cache. LRU = Least Recently Used
            .name(cacheName);
         
		net.sf.ehcache.Cache cache = new net.sf.ehcache.Cache(ehCacheConfig);

		ehCacheCacheManageFactory.getObject().addCache(cache);
		return new EhCacheCacheManager(ehCacheCacheManageFactory.getObject());
	}
	
	@Bean
	public EhCacheManagerFactoryBean ehCacheCacheManageFactory()
	{
		return new EhCacheManagerFactoryBean();
	}
}
