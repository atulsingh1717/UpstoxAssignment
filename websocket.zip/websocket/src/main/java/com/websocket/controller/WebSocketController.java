package com.websocket.controller;

import javax.inject.Inject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

import com.websocket.model.MarketDataModel;
import com.websocket.model.OpenHiLowCloseDataModel;
import com.websocket.service.ComputOpenHighLowCloseData;

@Controller
public class WebSocketController
{
	private static final Logger logger = LogManager.getLogger(WebSocketController.class);
	
	@Inject
	private ComputOpenHighLowCloseData<OpenHiLowCloseDataModel, MarketDataModel> computOpenHighLowCloseData;

	@MessageMapping("/greetings")
	@SendTo("/topic/greetings")
	public OpenHiLowCloseDataModel greeting(@Payload MarketDataModel message) throws Exception
	{		
		OpenHiLowCloseDataModel ohlcDataModel = computOpenHighLowCloseData.compute(message);	
		return ohlcDataModel;
	}
}
