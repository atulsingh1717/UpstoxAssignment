package com.websocket.controller;

import javax.inject.Inject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.websocket.exception.MarketWatchException;
import com.websocket.service.DataBroadcastService;

@Component
public class ApplicationStartup implements ApplicationListener<ApplicationReadyEvent>
{
	private static final Logger logger = LogManager.getLogger(ApplicationStartup.class);

	@Inject
	private DataBroadcastService<String> dataBroadcastService;

	@Override
	public void onApplicationEvent(ApplicationReadyEvent event)
	{
		try
		{
			dataBroadcastService.broadcastData();
		} catch(MarketWatchException e)
		{
			throw new RuntimeException("Unexpected Error Occure Post Application Is Ready", e);
		}
	}

}
