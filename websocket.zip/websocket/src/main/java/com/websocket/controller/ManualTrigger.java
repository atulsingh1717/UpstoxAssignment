package com.websocket.controller;

import javax.inject.Inject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.websocket.exception.MarketWatchException;
import com.websocket.service.DataBroadcastService;

@RestController
@RequestMapping("/manually")
public class ManualTrigger
{
	private static final Logger logger = LogManager.getLogger(ManualTrigger.class);
	
	@Inject
	private DataBroadcastService<String> dataBroadcastService;
	
	@Async("taskExecutor")
	@PostMapping("/trigger")
	public String dummy() throws MarketWatchException
	{
		dataBroadcastService.broadcastData();
		return "Successfull";
	}
}
