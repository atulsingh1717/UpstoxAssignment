package com.websocket.service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;

import javax.inject.Inject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.websocket.exception.MarketWatchException;
import com.websocket.model.MarketDataModel;
import com.websocket.model.OpenHiLowCloseDataModel;
import com.websocket.repository.DataRepository;

@Service
public class MarketDataBroadcastImpl implements DataBroadcastService<String>
{
	private static final Logger logger = LogManager.getLogger(MarketDataBroadcastImpl.class);

	@Value("${data.source.json.file: data//data.js}")
	private String directory;

	@Inject
	private DataRepository<MarketDataModel> jasonDataRepository;

	@Inject
	private ComputOpenHighLowCloseData<OpenHiLowCloseDataModel, MarketDataModel> computOpenHighLowCloseData;

	@Autowired
	private SimpMessagingTemplate template;

	@Override
	@Async("taskExecutor")
	public void broadcastData() throws MarketWatchException
	{
		while(true)
		{
			BufferedReader br = null;
			try
			{
				br = new BufferedReader(new InputStreamReader(new ClassPathResource(directory).getInputStream()));
				
				String line = null;
				while((line = br.readLine())!=null)
				{
					MarketDataModel model = jasonDataRepository.getData(line, MarketDataModel.class);
					OpenHiLowCloseDataModel ohlcDataModel = computOpenHighLowCloseData.compute(model);
					
					//Kept it to log at console to show pushed data at console
					logger.info("++++ Symbol : "+ohlcDataModel.getSymbol()+" O: "+ohlcDataModel.getO()+" H: "+ohlcDataModel.getH()+" L: "+ohlcDataModel.getL()+" C: "+ohlcDataModel.getC()+" BAR_NUM: "+ohlcDataModel.getBar_num()+" ++++ ");
					template.convertAndSend("/topic/greetings", ohlcDataModel);					
				}
			} catch(Exception e)
			{
				throw new MarketWatchException("Unable to get data from date source.", e);
			} finally
			{
				IOUtils.closeQuietly(br);
			}
		}
	}
}
