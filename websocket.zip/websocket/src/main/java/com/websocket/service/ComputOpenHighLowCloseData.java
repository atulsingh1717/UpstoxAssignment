package com.websocket.service;

public interface ComputOpenHighLowCloseData<O,I>
{
	public O compute(I model);
}
