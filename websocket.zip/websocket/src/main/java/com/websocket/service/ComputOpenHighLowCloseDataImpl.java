package com.websocket.service;

import java.util.Optional;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.Cache.ValueWrapper;
import org.springframework.stereotype.Service;

import com.websocket.model.MarketDataModel;
import com.websocket.model.OpenHiLowCloseDataModel;

@Service
public class ComputOpenHighLowCloseDataImpl implements ComputOpenHighLowCloseData<OpenHiLowCloseDataModel, MarketDataModel>
{
	private static final Logger logger = LogManager.getLogger(ComputOpenHighLowCloseDataImpl.class);
	@Inject
	private Cache cache;

	@Value("${packet.based.interval: 15}")
	private long interval;
	
	@Value("${ohlc.event.value: ohlc_notify}")
	private String event;
	
	private Long startTime;
	
	@Override
	public OpenHiLowCloseDataModel compute(MarketDataModel model)
	{
		if(startTime==null) 
			startTime = System.currentTimeMillis();
		
		OpenHiLowCloseDataModel ohlcModel = getCachedObject(model.getSym()).orElse(initializeOpenHiLowCloseDataModel(model));

		long millis = System.currentTimeMillis();

		if(ohlcModel.isTimeSlotChange())
			ohlcModel = resetOpenHiLowCloseDataModel(ohlcModel, model);
		else
		{
			ohlcModel.setH(ohlcModel.getH()>model.getP()?ohlcModel.getH():model.getP());
			ohlcModel.setL(ohlcModel.getL()>model.getP()?model.getP():ohlcModel.getL());
			ohlcModel.setVolume(model.getQ());
		}

		if(TimeUnit.MILLISECONDS.toSeconds(millis-startTime)==interval)
		{
			startTime = System.currentTimeMillis();
			ohlcModel.setC(model.getP());
			ohlcModel.setTimeSlotChange(true);
		}
		cache.put(model.getSym(), ohlcModel);
		return ohlcModel;
	}
	
	private Optional<OpenHiLowCloseDataModel> getCachedObject(String symbol)
	{
		ValueWrapper wrapper = cache.get(symbol);
		OpenHiLowCloseDataModel model = (OpenHiLowCloseDataModel) (wrapper!=null?wrapper.get() :null);
		return Optional.ofNullable(model);
	}
	
	private OpenHiLowCloseDataModel initializeOpenHiLowCloseDataModel(MarketDataModel model)
	{
		return OpenHiLowCloseDataModel.builder().o(model.getP()).h(model.getP()).l(model.getP())
				.volume(model.getQ()).event(event).symbol(model.getSym()).bar_num(1)
				.timeSlotChange(false).build();
	}	
	
	private OpenHiLowCloseDataModel resetOpenHiLowCloseDataModel(OpenHiLowCloseDataModel ohlcModel, MarketDataModel model)
	{
		ohlcModel.setO(model.getP());
		ohlcModel.setH(model.getP());
		ohlcModel.setL(model.getP());
		ohlcModel.setC(0);
		ohlcModel.setVolume(model.getQ());
		ohlcModel.setBar_num(ohlcModel.getBar_num()+1);
		ohlcModel.setTimeSlotChange(false);
		return ohlcModel;
	}

}
