package com.websocket.service;

import com.websocket.exception.MarketWatchException;

public interface DataBroadcastService<T>
{
	public void broadcastData() throws MarketWatchException;
}
