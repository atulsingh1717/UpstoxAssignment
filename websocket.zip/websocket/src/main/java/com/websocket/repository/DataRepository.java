package com.websocket.repository;

import com.websocket.exception.MarketWatchException;

public interface DataRepository<T>
{
	public T getData(String jasonString, Class<T> cls) throws MarketWatchException;
}
