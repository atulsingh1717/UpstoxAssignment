package com.websocket.repository;

import javax.inject.Inject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.websocket.exception.MarketWatchException;
import com.websocket.model.MarketDataModel;

@Repository
@Qualifier("jasonDataRepository")
public class JsonDataRepositoryImpl implements DataRepository<MarketDataModel>
{
	private static final Logger logger = LogManager.getLogger(JsonDataRepositoryImpl.class);

	@Inject
	private ObjectMapper objectMapper;

	@Override
	public MarketDataModel getData(String jsonString, Class<MarketDataModel> cls) throws MarketWatchException 
	{
		try
		{
			MarketDataModel model = objectMapper.readValue(jsonString, cls);
			return model;
		} catch(JsonProcessingException e)
		{
			logger.error(" Error : Bad request .");
			throw new MarketWatchException("Bad request please try later.", e);
		}

	}

}
