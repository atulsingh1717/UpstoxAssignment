package com.websocket.exception;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class MarketWatchException extends Exception
{

	private static final Logger logger = LogManager.getLogger(MarketWatchException.class);
	/**To Avoid UnmarshalException 
	 */
	private static final long serialVersionUID = 4271816825044973452L;

	public MarketWatchException()
	{
		super();
		logger.error(" Error : ", this);
	}

	public MarketWatchException(Throwable th)
	{
		super(th);
		logger.error(" Error : ", th);
	}

	public MarketWatchException(String message, Throwable th)
	{
		super(message, th);
		logger.error(" Error : ", th);
	}
}
