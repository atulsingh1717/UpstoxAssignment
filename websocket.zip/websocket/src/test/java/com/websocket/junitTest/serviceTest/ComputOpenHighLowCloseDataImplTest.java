package com.websocket.junitTest.serviceTest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.cache.Cache;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.websocket.model.MarketDataModel;
import com.websocket.model.OpenHiLowCloseDataModel;
import com.websocket.service.ComputOpenHighLowCloseDataImpl;

//@RunWith(MockitoJUnitRunner.class)
@RunWith(SpringJUnit4ClassRunner.class)
public class ComputOpenHighLowCloseDataImplTest
{
	
	@InjectMocks
	private ComputOpenHighLowCloseDataImpl computOpenHighLowCloseData;

	@Mock
	private Cache cache;
	
	@Before
	public void init()
	{
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testResetOpenHiLowCloseDataModel()
	{
		ComputOpenHighLowCloseDataImpl obj = new ComputOpenHighLowCloseDataImpl();
		
		
		MarketDataModel model = MarketDataModel.builder().sym("XZECXXBT").t("Trade").p(0.01947)
				.q(0.1).ts(1538409720.3813).side("s").ts2(1538409725339216503l).build();
		
		ArgumentCaptor<OpenHiLowCloseDataModel> valueCapture = ArgumentCaptor.forClass(OpenHiLowCloseDataModel.class);
		
		Mockito.doNothing().when(cache).put(Mockito.any(String.class), valueCapture.capture());		
		OpenHiLowCloseDataModel ohlcDataModel = computOpenHighLowCloseData.compute(model);		
		System.out.println(" ohlcDataModel: "+ohlcDataModel);
		Assert.assertNotNull(ohlcDataModel);
		
		ohlcDataModel.setTimeSlotChange(true);
	}
}
