 This application is sample combination of spring boot, websocket, queue & ehCache. It is aimed to demonstrate the working of market watsh tickers.

How To Use & Run:

	1. Data Source file have to placed at /resources/data directorey in order to be picked by application.
	
	2. There is WebsocketApplication.launch present to launch application in ide.
	
	3. For artifact runnable jar creation run below command 
			gradlew bootjar 
		this command will prepare deployabe and executable jar inside lib directory.
		
	5. To run the jar hit command given below	
			java -jar <jarname>.jar
			
	6. default port is 8080 and url is http://localhost:8080, post application startup connect to this url for UI access.
	
	7. At UI there are several buttons given which have description as below:
		
		Connect: To establish connection channel with websoket 
		
		Disconnect: To disconnect established channel with websocket
		
        Request Sender For All Data : It sends request which triggers direct broad cast of messages by reading them from sources and relay to websocket		
		
		Request Sender For Sample Data: I sends a sample payload to application which converts message payload to OHLC payload and relays to websocket which received by subscriber

 
2. There are few assumption considered.
	
	- The given JSON file in problem statement was considered primary data source so system is designed to use it.
	- The file have to be kept inside /websocket/src/main/resources/data to be detected by application while running in IDE as well as to be included inside artifact jar.
	- To imitate contineous stream of data coming from sources like data from stock exchanges for market-watch-ticker, the file has been read inside infinite loop, so it 
	  can produce similar effect and done intentionally to achieve same.
	- System is designed to adapt new data source with minimal development
	- one additional logger have been placed to print dumped data in websocket to show at console.
    - To imitate contineous market watch post Application ready event triggers data dumping in websocket, so any subscriber can get real time data.
	- System is designed to change data source in future wihout tightly coupled dependency.
	- 15 Minuet interal is specific to scrips where at very beigining 15 second bar window is started and kepts to specific that scrip while processing.
      We can change that logic as per future requirements.	
    

3. Basic Architecture:
    1. there is reader running in asynchronous thread which reads data from source
	2. this data is delegated to a Computational worker which computes open, high, low and close value from market data as per 15 second interval
	4. Simultaneously post fomputation, computation output is being dumped by reader in queue of websocket to be delivered to subscriber
	5. There is possible improvement over reader part which binds all business logic one point using various other designing techniques.
	
	
Future Improvements & Enhancements:
	1. Proper message broker like Active MQ or Kafka apis can be imtegrated as a layer between reader and computation engin.
	2. Front end subscriber will be improved to provide better and faster GUI
	3. Security aspects are still pending to be implemented will be included in further versions.
	4. Various monitoring and administration tool will be integrated like actuator etc.
	5. Implementation of all possible unit tests

	